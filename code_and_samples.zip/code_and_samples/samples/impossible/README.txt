This level of difficulty is not part of the assignment. It is here just in case you really want to challenge your algorithm ;-)
